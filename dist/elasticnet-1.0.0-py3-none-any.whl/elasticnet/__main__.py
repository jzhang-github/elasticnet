# -*- coding: utf-8 -*-
"""
Created on Wed Jul 12 10:36:45 2023

@author: ZHANG Jun
"""

from elasticnet.main import main
main()
